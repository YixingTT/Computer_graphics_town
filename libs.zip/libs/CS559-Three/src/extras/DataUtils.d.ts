export namespace DataUtils {

	export function toHalfFloat( val: number ): number;

}
